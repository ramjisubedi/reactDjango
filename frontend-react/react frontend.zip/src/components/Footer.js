import React from 'react'

const Footer = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-12 text-center py-2">
          Copyright &copy; 2023
        </div>
      </div>
    </div>
  )
}

export default Footer