const products = [
    {
        '_id':'1',
        'name':'Airpods 1',
        'image':'img',
        'description':'sdfhsdfhsjdhjsdhjksdh fjksdhfjksdhfjksdhfsdfh sd',
        'brand':'Apple',
        'ctegory':'Electron',
        'price':124,
        'countInStock':0,
        'rating':4,
        'numReviews':12
    },
    {
        '_id':'2',
        'name':'Airpods 2',
        'image':'img',
        'description':'sdfhsdfhsjdhjsdhjksdh fjksdhfjksdhfjksdhfsdfh sd',
        'brand':'Apple',
        'ctegory':'Electron',
        'price':124,
        'countInStock':0,
        'rating':4,
        'numReviews':12
    },
    
    {
        '_id':'3',
        'name':'Airpods 3',
        'image':'img',
        'description':'sdfhsdfhsjdhjsdhjksdh fjksdhfjksdhfjksdhfsdfh sd',
        'brand':'Apple',
        'ctegory':'Electron',
        'price':124,
        'countInStock':0,
        'rating':1,
        'numReviews':12
    },
    

];

export default products